import os
import shutil
import warnings
import time
from tpds.flash_program import FlashProgram
from tpds.tp_utils.tp_print import print
from hsm_protocol import Constants

import os
from cryptography import x509
from intelhex import IntelHex
from tpds.flash_program import FlashProgram
from tpds.tp_utils.tp_print import print
import tpds.tp_utils.tp_input_dialog as tp_userinput
from tpds.tp_utils.tp_keys import TPAsymmetricKey
from tpds.helper import log
import hid
warnings.filterwarnings('ignore')


class ProvisioningUsecase():
    def __init__(self, boards, publickeylen=0, VID=0x04D8, PID=0x003F, publickey_slot=15):
        self.boards = boards
        self.publickey_slot = publickey_slot
        self.VID = VID
        self.PID = PID
        self.hsm_usb = hid.device()
        self.publickeylen = publickeylen

 # Step 1
    def connect_to_SE(self, b=None):

        assert self.boards.get_selected_board(), \
            "Select board to run an Usecase"
        self.kit_parser = FlashProgram(board_name='EA14V17A')
        assert self.kit_parser.is_board_connected(), \
            "Check the board connection and select"
        print("Board Connect")
        assert self.kit_parser.is_factory_programmed(),\
            '\r\n   Kit Protocol Error:'\
            '\r\n       1.Check kit parser board connection'\
            '\r\n               OR      '\
            '\r\n       2.Reset the Board'\
            '\r\n               OR      '\
            '\r\n       3.Program Kit Protocol-Step 6'
        print("Programmed with Kit Protocol")
        assert self._discover_hsm() == Constants.hsm_found,\
            '\r\n   HSM not present:'\
            '\r\n   1. Reset the board'\
            '\r\n           OR'\
            '\r\n   2 .Program Kit protocol-Step 6'
        print("HSM Device found.")

        self.load_slotinfo()
        
    def load_slotinfo(self, b=None):
        print("Select HSM slot", canvas=b)
        text_box_desc = (
            '''<font color=#0000ff><b>HSM Slot</b></font><br>
        <br>The HSM slot must be a value between 1 and 254.<br>
        <br>Please enter the selected HSM slot:<br>''')
        user_input = tp_userinput.TPInputTextBox(
            desc=text_box_desc,
            dialog_title='HSM slot selection')
        user_input.invoke_dialog()
        print(f'Selected HSM slot is: {user_input.user_text}', canvas=b)
        assert user_input.user_text is not None, "Select a valid HSM slot"
        assert (int(user_input.user_text) > 0) and (int(user_input.user_text) < 255), \
            'The selected HSM slot is NOT valid'
        self.publickey_slot = int(user_input.user_text)

        Constants.RAW_FULLDATA_256[0] = self.publickeylen + \
            Constants.HEADER_BYTES
        Constants.RAW_FULLDATA_256[1] = self.publickey_slot << 8
        Constants.RAW_FULLDATA_256[4] = self.publickeylen

# Step 2

    def generate_resources_asymmetric_key(self, b=None):
        # Generate Private Public Key pair
        print("Generating key for provisioning...", canvas=b)
        self.secbootkey = TPAsymmetricKey(self.__get_private_key_file(b))
        privkey_file = 'private_key.pem'
        self.secbootkey.get_private_pem(privkey_file)
        self.publickey = self.secbootkey.get_public_key_bytes().hex().upper()
        self.publickeylen = int(len(self.publickey)/2)

        print(f"Public Key Bytes:", self.publickey, canvas=b)
        print(f"Public Key Length:", self.publickeylen, canvas=b)
        # 64 byte key

        # self.load_slotinfo()

        print("Completed.")


# Step 3

    def write_slot(self, b=None):
        print("Load Public Key to Slot %d:" % self.publickey_slot)
        assert self.publickeylen > 0, \
            "Generate Public Key Before Loading to Slot"
        assert self._hsm_load_public_key(
            self.publickey_slot,
            self.publickey,
            self.publickeylen) == "KIT_STATUS_SUCCESS",\
            "HSM Key Load Failed"
        print("HSM Write Complete", canvas=b)
        self.write_nvm()
        


# Step 4
    def read_slot(self, b=None):
        assert self.kit_parser.is_factory_programmed(),\
            "Reset Board/Program kit protocol(Step-6)"
        assert self._hsm_read(self.publickey_slot, self.publickeylen, info=None) == "KIT_STATUS_SUCCESS",\
            "HSM Read Failed,No Key in Slot"
        print("HSM Read Key Complete", canvas=b)


# Step 5

    def delete_slot(self, b=None):
        print("Delete Public Key of Slot %d:" % self.publickey_slot)
        assert self._delete_slot(self.publickey_slot) == "KIT_STATUS_SUCCESS",\
            "HSM Delete Failed"
        self.publickeylen = 0
        print("HSM Delete Complete", canvas=b)
        self.write_nvm()
        


# Step 6

    def flash_combined_firmware(self, b=None):
        print("Re-connect the power on the board")
        self.combined_hex = self.boards.get_kit_hex()
        flash_firmware = FlashProgram(board_name='EV16W43A')
        print(f'Programming {self.combined_hex} file...', canvas=b)
        flash_firmware.check_board_status()
        flash_firmware.load_hex_image_with_ipe(self.combined_hex)
        print('Success', canvas=b)
        print("Reset the board")

# Step 7

    def read_slotinfo(self, b=None):
        readinfo = True
        assert self._hsm_read(self.publickey_slot, self.publickeylen, readinfo) == "KIT_STATUS_SUCCESS",\
            "HSM Read Failed,No Key in Slot"
        print("HSM Read Info Complete", canvas=b)

############################################################################################

    def write_nvm(self, b=None):
        assert self._misc_write_nvm(self.publickey_slot) == "KIT_STATUS_SUCCESS", \
            "       HSM NVM Write Failed"
 
    def _misc_write_nvm(self, b=None):
        OUTDATA = b"\rhsm:talk(group[F0]cmd[06])\n"
        self.__write_hsm_hid(OUTDATA)
        status = self.__hsm_read_resp()
        return (status)    
    
    def _discover_hsm(self, b=None):
        hsmdiscovercmd = b"\rboard:device(00)\n"
        self.__write_hsm_hid(hsmdiscovercmd)
        hsm_response = self.__read_hsm_hid(64)
        hsm_discover = bytes(hsm_response)
        hsm_response_str = hsm_discover.decode()
        return (hsm_response_str.find('HSM'))

    def _hsm_load_public_key(self, slot, key, keylen, b=None):
        hsm_wr_cmd = self.__combine_cmd_dataforwrite(slot, key, keylen)
        print(" Sending Command and Data...\n\r   %s" %
              (hsm_wr_cmd))
        cmdLength = len(hsm_wr_cmd)
        numFullHidBufs = int(cmdLength/(Constants.HIDBUFSIZEBYTES+1))
        for i in range(numFullHidBufs):
            cmd_datastr = hsm_wr_cmd[i*(Constants.HIDBUFSIZEBYTES-1)
                                        :((i+1)*(Constants.HIDBUFSIZEBYTES-1))]
            cmd_datastr = b"\r" + cmd_datastr
            self.__write_hsm_hid(cmd_datastr)
        remBufferBytes = cmdLength % (Constants.HIDBUFSIZEBYTES+1)
        if (remBufferBytes > 0):
            cmd_datastr = b"\r" + \
                hsm_wr_cmd[numFullHidBufs*(Constants.HIDBUFSIZEBYTES-1):]
            self.__write_hsm_hid(cmd_datastr)
            status = self.__hsm_read_resp()
        return (status)

    def _hsm_read(self, slot, keylen, info, b=None):
        maxLength = 64
        maxNumBuffs = Constants.MAXRSPLENGTH/Constants.HIDBUFSIZEBYTES
        print(" Sending Command...")
        if info == True:
            hsm_readcmd = self.__hsm_read_slotinf_cmd(slot)
        else:
            hsm_readcmd = self.__hsm_read_slot_cmd(slot, maxLength)
        hsm_readcmdbtyes = bytes(hsm_readcmd, 'utf-8')
        self.__write_hsm_hid(hsm_readcmdbtyes)
        eoc = False
        rsp = b""
        rspLen = 0
        numBuffs = 0
        while (True):
            d = self.__read_hsm_hid(64)
            numBuffs += 1
            if d:
                ds = bytes(d)
                # print("\n %s" % (bytearray(d).hex('/', 1)))
                delIdx = ds.find(0x0a)
                if (delIdx > -1):
                    rspLen += delIdx
                    rsp += ds[:delIdx+1]
                    eoc = True
                    break
                else:
                    rsp += ds
                    rspLen += Constants.HIDBUFSIZEBYTES
            else:
                eoc = True
                break
            if (numBuffs > maxNumBuffs):
                break
        # print("RSP:  %s" % (rsp))
        self.kc = int(rsp[:2], 16)
        rc = int(rsp[3:11], 16)
        dStart = rsp.find(0x28)+1  # '('
        dEnd = rsp.find(0x29)  # ')'
        if (dEnd > 0):
            dLength = dEnd-dStart
            # print("Data length:  %d" % (dLength))
            dData = rsp[dStart:(dEnd)]
            dWords = int(dLength/(Constants.CHARSPERWORD))
            dRem = dLength % (Constants.CHARSPERWORD)
            if (info == True):
                print(" Read Slot Info:")
            for i in range(dWords):
                ws = dStart + i*Constants.CHARSPERWORD
                # read_key = (rsp[ws:we])
                if (i <= 5):
                    we = ws + Constants.CHARSPERWORD
                    if (info == True):
                        print("  W%02d: %s " %
                            (i, (rsp[ws:we])), Constants.slot_info_words[i])
                else:
                    print(" Read Key Bytes:")
                    print("   %s" % (rsp[ws:dEnd]))
                    break

            if (dRem > 0):
                print("  W%02d: %s" % (i, (rsp[we-dRem:we])))
            # print("RC = 0x%04x" % (rc))
            # print("KC(%02x)%s \r\n" % (self.kc, Constants.kcDictR[self.kc]))
            return (Constants.kcDictR[self.kc])

        else:
            print("VSM_SLOT_INFO Response Error!!!")   

    def _delete_slot(self, slotnum, b=None):
        OUTDATA = b"\rhsm:talk(group[03]cmd[04]slot[%02x])\n" % slotnum
        self.__write_hsm_hid(OUTDATA)
        status = self.__hsm_read_resp()
        return (status)

    def __hsm_read_slot_cmd(self, slotnum, dataLength, b=None):
        OUTSTR = "\rhsm:talk(group[03]cmd[01]slot[%02x]length[%02x])\n" % (
            slotnum, dataLength)
        print(OUTSTR)
        return (OUTSTR)

    def __hsm_read_slotinf_cmd(self, slotnum, b=None):
        OUTSTR = "\rhsm:talk(group[03]cmd[05]slot[%02x])\n" % slotnum
        print(OUTSTR)
        return (OUTSTR)

    def __hsm_read_resp(self, b=None):
        d = ""
        d = self.__read_hsm_hid(64)
        if d:
            ds = bytes(d)
        kc = int(ds[:2], 16)
        return (Constants.kcDictR[kc])

    def __open_hid(self, b=None):
        self.hsm_usb = hid.device()
        self.hsm_usb.open(self.VID, self.PID)

    def __write_hsm_hid(self, msg, b=None):
        self.__open_hid()
        assert self.hsm_usb.write(msg), 'Not able to wirte the HSM'
        time.sleep(0.05)

    def __read_hsm_hid(self, byt, b=None):
        response = self.hsm_usb.read(byt)
        return response

    def __combine_cmd_dataforwrite(self, slot, key, keylen, b=None):

        dataLenWords = int((keylen/4) + (Constants.HEADER_BYTES)/4)
        OUTSTR = "hsm:talk(group[03]cmd[00]slot[%02x]length[%02x]" % (slot,
                                                                      (dataLenWords+1))

        OUTDATA = bytes(OUTSTR, 'utf-8')
        OUTKEY = bytes(key, 'utf-8')
        OUTDATA += b'data['
        for w in Constants.RAW_FULLDATA_256:
            wle = int.from_bytes(w.to_bytes(4, byteorder='little'),
                                 byteorder='big',  signed=False)
            OUTDATA += bytes("%08x" % wle, 'utf-8')
        OUTDATA += OUTKEY
        OUTDATA += b"])\n"
        return (OUTDATA)

    def __get_private_key_file(self, b=None):
        print("Select secure boot private key option", canvas=b)
        item_list = ["Generate Private key", "Upload Private key"]
        dropdown_desc = """<font color=#0000ff><b>Select Secure Boot private key option</b>
        </font><br>
        <br>Generate Private key - Generates new Secure Boot private key<br>
        Upload Private key - Use existing private key file. Requires
        private key file .pem<br>"""
        user_input = tp_userinput.TPInputDropdown(
            item_list=item_list,
            desc=dropdown_desc,
            dialog_title="Private key selection",
        )
        user_input.invoke_dialog()
        print(f"Selected option is: {user_input.user_option}", canvas=b)
        assert user_input.user_option is not None, "Select valid private key Option"

        if user_input.user_option == "Upload Private key":
            print("Select private key file...", canvas=b)
            privkey = tp_userinput.TPInputFileUpload(
                file_filter=["*.pem"],
                nav_dir=os.getcwd(),
                dialog_title="Upload Private key",
            )
            privkey.invoke_dialog()
            print(
                f"Selected private key file is: {privkey.file_selection}", canvas=b)
            assert privkey.file_selection is not None, "Select valid private key file"
            return privkey.file_selection
        else:
            return None

    # def __create_combined_firmware(self, b=None):
    #     hex_files = self.__get_boot_hex_and_app_hex(b)
    #     self.combined_hex = 'combined_image.hex'
    #     self.combined = IntelHex()

    #     print('Combining kit protocol and hsm flash boot image...', canvas=b)
    #     boot_hex = 'boot.hex'
    #     shutil.copy(hex_files.get('boot'), boot_hex)
    #     self.combined.merge(IntelHex(boot_hex), overlap='replace')
    #     os.remove(boot_hex)

    #     app_hex = 'applicaion.hex'
    #     shutil.copy(hex_files.get('app'), app_hex)
    #     self.combined.merge(IntelHex(app_hex), overlap='replace')
    #     os.remove(app_hex)

    #     self.combined.tofile(self.combined_hex, format='hex')
    #     print('Completed', canvas=b)
    #     print(f'Combined image file is: {self.combined_hex}', canvas=b)

    # def __get_boot_hex_and_app_hex(self, b=None):
    #     print('Select kit Protocol file...', canvas=b)
    #     kit_protocol = tp_userinput.TPInputFileUpload(
    #         file_filter=['*.hex'],
    #         nav_dir=os.getcwd(),
    #         dialog_title='Upload kit protocol hex')
    #     kit_protocol.invoke_dialog()
    #     print(
    #         f'Selected Kit Protocol file is: {kit_protocol.file_selection}',
    #         canvas=b)
    #     assert kit_protocol.file_selection is not None, \
    #         'Select valid Kit Protocol hex file'

    #     print('Select HSM flash boot image file...', canvas=b)
    #     hsm_flash = tp_userinput.TPInputFileUpload(
    #         file_filter=['*.hex'],
    #         nav_dir=os.getcwd(),
    #         dialog_title='Upload hsm flash boot hex')
    #     hsm_flash.invoke_dialog()
    #     print(
    #         f'Selected hsm flash boot file is: {hsm_flash.file_selection}',
    #         canvas=b)
    #     assert hsm_flash.file_selection is not None, \
    #         'Select valid hsm flash boot image file'

    #     return {
    #         'boot': kit_protocol.file_selection,
    #         'app': hsm_flash.file_selection
    #     }
